# OSM Elite Assistant

## Deploy en Vercel

1. Subí esta carpeta a GitHub
2. Importá el repositorio en Vercel
3. Vercel detectará automáticamente Next.js
4. Deploy automático

## Desarrollo local

```bash
npm install
npm run dev
```
