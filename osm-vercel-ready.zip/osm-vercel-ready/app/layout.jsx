export const metadata = {
  title: 'OSM Elite Assistant',
  description: 'Asistente táctico avanzado para OSM',
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body style={{ margin: 0, padding: 0, background: '#0f172a' }}>
        {children}
      </body>
    </html>
  );
}
